import java.sql.*;
import java.io.*;
import java.util.Properties;

public class DatabaseOperations {
    private Connection conn;

    public DatabaseOperations() {
        try {
            Properties props = new Properties();
            FileInputStream in = new FileInputStream("alfa3/src/config.properties");
            props.load(in);
            in.close();

            String url = props.getProperty("database.url");
            String username = props.getProperty("database.username");
            String password = props.getProperty("database.password");

            conn = DriverManager.getConnection(url);
        } catch (IOException | SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void insertData(String[] data) {
        try {
            String sql = "INSERT INTO Citizens (Name, Surname, Birthdate, Birthplace) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, data[0]);
            pstmt.setString(2, data[1]);
            pstmt.setDate(3, Date.valueOf(data[2]));
            pstmt.setString(4, data[3]);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }


    public void deleteData(String id) {
        try {
            String sql = "DELETE FROM Citizens WHERE ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, Integer.parseInt(id));
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }


    public void updateData(String[] data) {
        try {
            String sql = "UPDATE Citizens SET Name = ?, Surname = ?, Birthdate = ?, Birthplace = ? WHERE ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, data[0]);
            pstmt.setString(2, data[1]);
            pstmt.setDate(3, Date.valueOf(data[2]));
            pstmt.setString(4, data[3]);
            pstmt.setInt(5, Integer.parseInt(data[4]));
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public void insertCitizenAndIDCard(String[] citizenData, String[] idCardData) {
        try {
            // Start transaction
            conn.setAutoCommit(false);

            // Insert into Citizens table
            String sql1 = "INSERT INTO Citizens (Name, Surname, Birthdate, Birthplace) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt1 = conn.prepareStatement(sql1, Statement.RETURN_GENERATED_KEYS);
            pstmt1.setString(1, citizenData[0]);
            pstmt1.setString(2, citizenData[1]);
            pstmt1.setDate(3, Date.valueOf(citizenData[2]));
            pstmt1.setString(4, citizenData[3]);
            pstmt1.executeUpdate();

            // Get generated citizen ID
            ResultSet rs = pstmt1.getGeneratedKeys();
            rs.next();
            int citizenID = rs.getInt(1);

            // Insert into ID_Cards table
            String sql2 = "INSERT INTO ID_Cards (ID_Card_Number, Issue_Date, Expiry_Date, Citizen_ID, Is_Valid) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt2 = conn.prepareStatement(sql2);
            pstmt2.setString(1, idCardData[0]);
            pstmt2.setDate(2, Date.valueOf(idCardData[1]));
            pstmt2.setDate(3, Date.valueOf(idCardData[2]));
            pstmt2.setInt(4, citizenID);
            pstmt2.setBoolean(5, Boolean.parseBoolean(idCardData[3]));
            pstmt2.executeUpdate();

            // Commit transaction
            conn.commit();
        } catch (SQLException ex) {
            // Rollback transaction if something goes wrong
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public String generateReport() {
        StringBuilder report = new StringBuilder();
        try {
            String sql = "SELECT Addresses.City, COUNT(*) AS CitizenCount " +
                    "FROM Citizens " +
                    "JOIN Citizens_Addresses ON Citizens.ID = Citizens_Addresses.Citizen_ID " +
                    "JOIN Addresses ON Citizens_Addresses.Address_ID = Addresses.ID " +
                    "GROUP BY Addresses.City";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String city = rs.getString("City");
                int count = rs.getInt("CitizenCount");
                report.append("City: ").append(city).append(", Citizen Count: ").append(count).append("\n");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return report.toString();
    }

}
