import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UserInterface extends JFrame {
    private JTextField textField;
    private JTextArea textArea;
    private DatabaseOperations dbOps;

    public UserInterface() {
        // Create user interface
        textField = new JTextField(40);
        textArea = new JTextArea(8, 40);
        JScrollPane scrollPane = new JScrollPane(textArea);

        Box box = Box.createHorizontalBox();
        box.add(textField);
        box.add(new JButton(new InsertAction()));
        box.add(new JButton(new DeleteAction()));
        box.add(new JButton(new UpdateAction()));
        box.add(new JButton(new InsertCitizenAndIDCardAction()));
        box.add(new JButton(new GenerateReportAction()));

        add(scrollPane, BorderLayout.CENTER);
        add(box, BorderLayout.SOUTH);
        pack();

        dbOps = new DatabaseOperations();
    }

    private class InsertAction extends AbstractAction {
        InsertAction() {
            super("Insert");
        }

        public void actionPerformed(ActionEvent event) {
            String input = textField.getText();
            String[] data = input.split(",");
            dbOps.insertData(data);
            textArea.append("Data inserted into Citizens table\n");
        }
    }

    private class DeleteAction extends AbstractAction {
        DeleteAction() {
            super("Delete");
        }

        public void actionPerformed(ActionEvent event) {
            String input = textField.getText();
            dbOps.deleteData(input);
            textArea.append("Data deleted from Citizens table\n");
        }
    }

    private class UpdateAction extends AbstractAction {
        UpdateAction() {
            super("Update");
        }

        public void actionPerformed(ActionEvent event) {
            String input = textField.getText();
            String[] data = input.split(",");
            dbOps.updateData(data);
            textArea.append("Data updated in Citizens table\n");
        }
    }

    private class InsertCitizenAndIDCardAction extends AbstractAction {
        InsertCitizenAndIDCardAction() {
            super("Insert Citizen and ID Card");
        }

        public void actionPerformed(ActionEvent event) {
            String input = textField.getText();
            String[] data = input.split(",");
            String[] citizenData = new String[]{data[0], data[1], data[2], data[3]};
            String[] idCardData = new String[]{data[4], data[5], data[6], data[7], data[8]};
            dbOps.insertCitizenAndIDCard(citizenData, idCardData);
            textArea.append("Citizen and ID card inserted\n");
        }
    }

    private class GenerateReportAction extends AbstractAction {
        GenerateReportAction() {
            super("Generate Report");
        }

        public void actionPerformed(ActionEvent event) {
            String report = dbOps.generateReport();
            textArea.append(report);
        }
    }
}
